<?php
  session_start();
  $con = mysqli_connect("localhost","root","","produk");

    if (isset($_POST["add"])){
    if(isset($_SESSION["Cart"])){
      $item_array_id = array_column($_SESSION["Cart"],"product_id");
      if (!in_array($_GET["id"],$item_array_id)){
        $count = count($_SESSION["Cart"]);
        $item_array = array(
          'product_id'=> $_GET["id"],
          'item_name'=> $_POST["hidden_nama"],
          'product_price' => $_POST["hidden_harga"],
          'item_quantity' => $_POST["quantity"],
        );
      $_SESSION["Cart"][$count]= $item_array;
        echo '<script>window.location="dashboard.php"</script>';
        }else{
          echo '<script>alert("product is already added to cart")</script>';
          echo '<script>window.location="dashboard.php"</script>';
        }
      }else{
        $item_array= array(
          'product_id'=> $_GET["id"],
          'item_name'=> $_POST["hidden_nama"],
          'product_price' => $_POST["hidden_harga"],
          'item_quantity' => $_POST["quantity"],
        );
        $_SESSION['Cart'][0] = $item_array;
      }
  }
  if (isset($_GET["action"])) {
    if ($_GET["action"] == "delete"){
      foreach ($_SESSION["Cart"] as $keys => $value){
        if ($value["product_id"] == $_GET ["id"]){
          unset($_SESSION["Cart"][$keys]);
          echo '<script>alert("produk has been removed")</script>';
          echo '<script>window.location="dashboard.php"</script>';
        }
      }
      # code...
    }
  }
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>SHOPING CART</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="dashboard1.css" rel="stylesheet">
    <style>
      .produk{
        border: 1px solid #eaeaec;
        margin:-1px 19px 3px -1px;
        padding: 10px;
        text-align: center;
        background-color: pink: 
      }
      table, th, tr{
        text-align: center;
      }
      .title2{
        text-align: center;
        color: : blue;
        background-color: #efefef;
        padding: 2%; 
      }
      h2{
        text-align: center;
        color: blue;
        background-color: #efefef;
        padding: 2%;

      }
      table th{
        background-color: #efefef;

      }
    </style>

  </head>
<body style="background-color: grey">

        <center>

          <h1 style="color: white">SHOPING CART</h1>
        </center>
        </div>
          <br><br><br>
          <?php 
            $query = "SELECT * FROM satu ORDER BY id ASC ";
            $result = mysqli_query($con,$query);
            if (mysqli_num_rows($result) > 0) {
            
              while ($row = mysqli_fetch_array($result)) {
            
                   ?><br><br>
                <div class="col-md-3" style="columns: 35%">
                  <form method="post" action="dashboard.php?action=add&id=<?php echo $row['id']; ?>">

                    <div class="column">
                      <img src="<?php echo $row['gambar']; ?>" class="img-responsive">
                      <h5 class="text-info"><?php echo  $row['nama']; ?></h5>
                      <h5 class="text-danger"><?php echo $row['harga']; ?></h5>
                      <input type="text" name="quantity" class="form-control" value="1">
                      <input type="hidden" name="hidden_nama" value="<?php echo $row['nama']; ?>">
                      <input type="hidden" name="hidden_harga" value="<?php echo $row['harga']; ?>">
                      <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-succes" value="add to Cart">
                    </div>
                  </form>
                </div>
                <?php
              }
            }
            ?>  
     
       <div style="clear: grey"></div>
       <h3 class="title2">Shoping Cart Details</h3>
       <div class="table-responsive">
          <table class="table table-responsive">
         <tr>
          <br>
           <h3><th width="30%">produck name</th></h3>
           <h3><th width="10%">quantity</th></h3>
           <h3><th width="13%">price details</th></h3>
          <h3><th width="17%">total price</th></h3>
          <h3><th width="17%">option</th></h3>
         </tr>
         <?php
          if (!empty($_SESSION["Cart"])) {
            $total= 0;
            foreach ($_SESSION["Cart"] as $key => $value) {
                 ?>
                 <tr>
                  <td><?php echo $value["item_name"]; ?></td>
                   <td><?php echo $value["item_quantity"]; ?></td>
                   <td>$ <?php echo $value["product_price"] ?></td>
                  <td>$ <?php echo number_format( $value["item_quantity"] * $value["product_price"]); ?></td>
                  <td><a href="dashboard.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span class="text-danger">remove item</span></a></td>              
                 </tr>
                 <?php 
                  $total= $total + ($value["item_quantity"] * $value["product_price"]);
              }
                 ?>
                 <tr>
                   <td colspan="3" align="right">total</td>
                   <th align="right">$ <?php echo number_format($total); ?></th>
                  <td></td> 
                 </tr>
                 <?php 
               }
               ?>
              </table>
           <tr>
           <div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
          <div class="list-group">
          <ul class="nav navbar-nav">
          <li class="active"><a href="index.php" class="list-group-item active">back to home</a></li>
          </ul>
          </div>
         </tr>
       </div>
      </div>
    </div>


   
          
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>

  </body>
</html>
