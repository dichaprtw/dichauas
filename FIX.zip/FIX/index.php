
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Starter Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="starter-template.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">HOME</a>
        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
       <li class="active"class="dropdown">
        <a data-toggle="dropdown" href="2.html">KATEGORI</a>
             <ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
          <li>
          <a href="dashboard.php">KOSMETIK </a>
        
         <li>
           <a href="smartphone.php">SMARTHPHONE</a>
          </li>
           <li>
           <a href="jam.php">JAM TANGAN</a>
          </li>
     </ul>
   </li>
            <li><a href="3.html">Contact</a></li>
            <li><a href="4.html">others</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>

 <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>
  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="gambar/bbrus.jpg" alt=" ">
         <div class="carousel-caption">
        <h1> HAPPY SHOPING </h1>
         </div>
          first
    </div>
        <div class="item ">
          <img src="gambar/b3.jpg" alt=" ">
           <div class="carousel-caption">
            <h3>SELAMAT BELANJA </h3>
           </div>
          second
        </div>
     
      <div class="item ">
         <img src="gambar/k1.jpg" alt=" ">
         <div class="carousel-caption">
           <h3> PURPLE</h3>
         </div>
         third
      </div>
</div>
  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
  </a>
</div>
 
 <br>
 <h2>"KETAHUILAH HARGA,HITUNG UANG ANDA, BARU BELANJA" </h2>
 <h3>uang nggak cukup didepan kasir itu tidaklah manish,trimms</h3>
 <div class="progress progress-striped">
  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
    <span class="sr-only">60% Complete (warning)</span>
  </div>
  HELPFULL
</div>
<div class="progress progress-striped">
  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
    <span class="sr-only">80% Complete (danger)</span>
  </div>
  NICEEE DISPLAY 
</div>
 <table class="table table-hover table-bordered">
      <h3>NETIJEN'S COMMENT</h3>
      <br>
      <tr>
        <th>name</th>
        <th>comment</th>
      </tr>

      <tr>
        <td>dicha </td>
        <td>sangat fast membantu saya,terima kasihh!!!</td>
      </tr>
       <tr>
        <td>naila</td>
        <td>wahh terima ksih,saya sangat puasss!!!</td>
      </tr>
      
    </table>
        </div>
      </div>
        </div>
      </div>

        </div>
      </div>




    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
  </body>
</html>
